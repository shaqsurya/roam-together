# Roam Together

A web-based travel workspace for itineraries, locations, budgets, upfront payments, shared costs, and repayments. The app is static HTML/CSS/JavaScript and can run on free GitHub Pages hosting. No payment service, subscription, backend server, or build pipeline is needed to use the local app.

## Current delivery

Public app: https://shaqsurya.github.io/roam-together/

Firebase project `roam-together-1c722` is configured on Spark with Google sign-in and a production-mode Standard Firestore database in `europe-west3` (Frankfurt). The tested access rules are published. No billing account was linked. The public deployment contains the website files at the repository root; the full developer project remains in this directory and is also provided as a source ZIP in the public repository.

- Working responsive app with Today, Plan, Money, and Trip screens.
- Create another trip with **New trip** in the top bar on every screen, including mobile. Switch existing trips in **Trip & friends → Switch adventure**.
- Multiple local trips, named travelers, activity participants, booking notes, meeting points, and map/directions links.
- Planned costs with upfront payer, due date, provider, actual paid amount, and remaining amount. Set a default upfront payer in Trip settings.
- Equal, exact, and percentage expense splits; multiple upfront payers; manual currency conversion; installments and linked refunds.
- Per-person spending and funding views, net settlement suggestions, pending/confirmed partial repayments, and reversals.
- Checklists, search, JSON backup/import, CSV exports, and printable itinerary/budget. Sample data is fictional and can be reset in Trip.
- Firebase adapter and access rules for live group editing, immediate link access without guest sign-in, personal expenses, and repayment recording. **Live sharing uses the configured Firebase project; local-only trips remain available separately.**
- Offline app shell and local-trip access after the first visit. Cloud changes that fail to save are kept as downloadable drafts when device storage is available.

## Run locally

Use Node.js 22 or later for the static app:

```sh
npm run dev
```

Open the printed `http://localhost:4173/` address. No dependency installation is required for serving the app or running its calculation tests. Opening `index.html` directly from the filesystem will not work because ES modules need HTTP.

```sh
npm test
npm run check
npm run build
```

`dist/` is already the deployable app. The build command verifies its assets; it does not generate or alter user records. Data created on localhost belongs to that browser/origin, so export JSON before switching to a hosted URL. Backups can be imported at the new address.

## Publish for free on GitHub Pages

1. Create a public GitHub repository for this directory. Upload the source, including `dist/`, `.github/workflows/pages.yml`, and the README. Never upload `node_modules`, private keys, or real trip backups.
2. In repository Settings → Pages → Build and deployment, choose **GitHub Actions**.
3. Push to the `main` branch, or manually run **Publish Roam Together** in Actions.
4. Open the URL returned by the deployment, typically `https://USERNAME.github.io/REPOSITORY/`.

Asset URLs, service-worker scope, and invite links support a repository subpath. App changes require redeployment; trip edits go directly to the database once Firebase is configured. Use GitHub's free default address; a custom domain is optional and outside the $0 plan.

A private Sites preview, if supplied with this delivery, is separate from GitHub Pages. Its private audience does not give friends public access. Export any preview data before moving to another origin.

## Enable free live sharing

Keep Firebase on **Spark**. Do not link a Cloud Billing account, enable Blaze, or start a billing-backed trial. Quota exhaustion can interrupt availability; it does not make capacity unlimited. All trips share your project's free allowances.

1. In [Firebase console](https://console.firebase.google.com/), create a project. Account terms must be accepted by you or with your explicit approval. Skip Gemini, Analytics, developer-program enrollment, and billing integrations; the app does not need them.
2. Add a **Web app** and copy its public Firebase configuration object. Do not enable Firebase Hosting for this GitHub Pages deployment.
3. Under Build → Authentication, enable **Google** as the sign-in provider. Set the support email as required by Firebase.
4. Add your deployed domain, for example `USERNAME.github.io`, to Authentication → Settings → Authorized domains. Add `localhost` if testing sign-in locally. If using a Sites preview as well, authorize that exact host too. Do not enter a path in the domain list.
5. Under Build → Firestore Database, create the **Standard edition** default database in an appropriate region. Choose production mode, then replace the initial rules with the exact contents of `firestore.rules` and publish them. Never use open test-mode rules for real trip data.
6. Edit `dist/firebase-config.js`, replacing `null` with your **public web configuration**, then redeploy the site. This configuration is meant to be public. Never put a service account JSON key or private token in browser code.
7. Open the app → Invite friends → Save to cloud & get link → sign in with Google. Upload a local trip with no existing repayment records. The first upload creates a new cloud trip and links the creator's account to the trip's original traveler.
8. Copy the trip link. Friends open it immediately, without sign-in or approval. They can choose their traveler for the money view, edit the trip, and record repayment receipts. For older restricted trips, the owner uses Invite friends → Enable link sharing once.

The optional in-app **Connect public web configuration** form is useful during setup and stores the configuration for this browser session only. A usable invitation for everyone requires the configuration in the deployed file.

There are no automatic invitation emails, SMS messages, uploads, paid map APIs, or exchange-rate API calls. Share links through your own messaging app. Maps and booking buttons open external sites.

### Security and storage model

This release uses a bounded, revisioned trip snapshot plus separate repayment records. New shared trips use unguessable UUID links: anyone holding a link can view and edit plans, travelers, budget, expenses, and receipt confirmations without signing in. Trip listing, account indexes, ownership, access metadata, deletion of shared trips, and repayment history remain protected. Existing restricted trips stay restricted until their owner chooses Invite friends → Enable link sharing once; their existing links then work immediately. The creator signs in with Google to create a cloud trip. Nested expense math is validated by the app before saving and after loading. Personal expenses charge one traveler as both payer and beneficiary, so they create no debt; they are visible to everyone with access to that shared trip.

A trip supports up to 20 people, 60 days, 300 activities, 300 planned costs, 400 expense/refund records, and 200 tasks. Client validation limits serialized trip data to 600,000 characters, and Firestore separately enforces its document byte limit. Emoji and other multi-byte text can reach that byte limit earlier; a failed save is kept as a draft. Repayments are separate documents; the UI validates up to 400 repayment records per trip. Archive and export a completed trip before starting the next.

Cloud saves use a revision transaction. A stale financial edit is rejected and retained as a draft, so it can be reviewed rather than silently overwriting another person's changes. Cloud trip records are not intentionally persisted to localStorage during normal viewing; Firebase auth uses session persistence. A failed edit is retained locally as a draft and therefore can contain trip details. Download it in Trip → Download unsaved draft, and import it as a separate local trip for review. Clear site data on a shared device after backing up. Members may retain previously downloaded copies after access removal.

Do not change a trip's base currency after creating money records. Each foreign-currency expense retains its own manual rate and uses integer minor units. Repayments are currently entered in the base currency. Planned costs have equal estimated shares; actual expense shares can be customized. Date/time comparisons use entered local times; overnight transport should use separate departure and arrival entries.

Initial cloud upload deliberately does not migrate historical repayment confirmations from a local file. Keep your exported history and start sharing before friends begin recording repayments.

### Access-rule tests

Rules tests run locally against the Firestore Emulator; they do not use or charge a real cloud project. They require Node.js 24.12+ and Java 21+:

```sh
npm ci
npm run test:rules
```

`npm test` runs 38 calculation/import/export tests, including randomized cent allocation and settlement reconciliation. `npm run test:rules` runs 28 access-rule tests covering legacy restricted trips, account indexes, no-sign-in link reads and writes, immutable owner/access metadata, revisions, manual repayment receipts, and archived trips. Expected permission-denied logs are part of the denied-access tests.

### Cost references

- [GitHub Pages limits and permitted use](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits)
- [Firebase Spark plan](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans)
- [Firestore quotas](https://firebase.google.com/docs/firestore/quotas)
- [Firebase Authentication limits](https://firebase.google.com/docs/auth/limits)

## Code map

- `dist/app.js`: interface, forms, local persistence, exports, and workflows.
- `dist/core.js`: validated data model, money calculations, allocation, and sample trip.
- `dist/cloud.js`: Firebase creator sign-in, subscriptions, revisions, link sharing, and receipt operations.
- `dist/styles.css`: responsive layout, accessible interaction states, and print styles.
- `firestore.rules`: group access and repayment permissions.
- `.github/workflows/pages.yml`: GitHub Pages deployment.

No private credentials are included. Google sign-in, a private trip upload, reopening by invitation ID, and a cloud checklist save have been exercised against the configured project. Role boundaries are covered by the emulator suite; a second person’s Google account was not used during setup.

### Budget and daily use

Use **Set budget** on Overview or Budget & costs. Enter one total for the whole group, in the trip currency. The form previews an approximate equal allowance per traveler and the amount left after expenses. Budget & costs also compares spending plus remaining planned costs against the limit. Use **Add planned cost** before paying; use **Add expense** after paying to calculate shares and balances. The Overview shortcuts provide direct access to friends, budget, activities, and expenses.

### Personal expenses and instant links

Choose **Add expense → Personal — no split** for an individual purchase. Select who paid for their own expense; split and multiple-payer controls are hidden. Choose **Shared with friends** when a payment is shared or someone paid for another traveler. **Invite friends → Save to cloud & get link** creates an immediately usable invitation. The creator signs in once; guests simply open the link and choose their name for the money view. For an older cloud trip, its owner uses **Invite friends → Enable link sharing** once.

### Joint trip and personal spaces

The workspace switch at the top of every screen offers **Joint trip (Master)** and one **Personal space** per traveler. Use **Add friend** beside it whenever someone joins an existing trip; a personal space appears automatically, without creating another trip. Renaming a traveler preserves payments and adding someone never changes old expense shares.

The master workspace holds shared expenses and joint payment plans. Each personal space shows that traveler's own ledger, their individual share of joint costs, repayments, and upcoming personal/group costs. Personal expense and plan forms default to that traveler and can link to the same shared itinerary activity. Explicit workspace tags distinguish new records; older records are classified from their existing payer/beneficiary information without changing amounts. The whole-trip budget and forecast continue to include shared and personal costs together, with separate subtotals.

These are named ledgers in one shared trip, with the existing anyone-with-link view/edit access. They are not separate authentication accounts or private financial records. Full-trip backups and CSV exports contain every workspace.
