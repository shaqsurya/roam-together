import {access,readFile} from 'node:fs/promises';
for(const f of ['index.html','app.js','core.js','cloud.js','session.js','styles.css','sw.js','manifest.webmanifest','icon.svg'])await access('dist/'+f);
const html=await readFile('dist/index.html','utf8');if(!html.includes('type="module"'))throw Error('Module entry point missing');
console.log('Static app ready in dist/ (GitHub Pages compatible).');
