import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve('dist');const port=Number(process.env.PORT||4173);
http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost');let file=path.resolve(root,'.'+decodeURIComponent(url.pathname));if(!file.startsWith(root+path.sep)&&file!==root)throw Error();if(url.pathname.endsWith('/'))file=path.join(file,'index.html');const data=await fs.readFile(file);res.writeHead(200,{'Content-Type':({'html':'text/html','js':'text/javascript','css':'text/css','json':'application/json','webmanifest':'application/manifest+json','svg':'image/svg+xml'})[file.split('.').pop()]||'application/octet-stream','Cache-Control':'no-cache'});res.end(data);}catch{res.writeHead(404);res.end('Not found');}}).listen(port,'0.0.0.0',()=>console.log('Local: http://localhost:'+port));
