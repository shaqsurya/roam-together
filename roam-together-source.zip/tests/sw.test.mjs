import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const code=await readFile('dist/sw.js','utf8');
function harness(){const handlers={},deleted=[];const shell=new Response('cached app shell');const caches={open:async()=>({addAll:async()=>{},put:async()=>{}}),keys:async()=>['roam-v1','roam-together-v2','another-app-cache'],delete:async key=>{deleted.push(key);},match:async key=>key==='./index.html'?shell:undefined};const self={addEventListener:(name,fn)=>{handlers[name]=fn;},location:{origin:'https://example.com'},clients:{claim:()=>{}},skipWaiting:()=>{}};vm.runInNewContext(code,{self,caches,fetch:async()=>{throw Error('offline');},URL,Response});return {handlers,deleted,shell};}
test('an offline trip URL with a query string falls back to the cached app shell',async()=>{const h=harness();let response;h.handlers.fetch({request:{method:'GET',mode:'navigate',url:'https://example.com/?trip=known'},respondWith:p=>{response=p;}});assert.equal(await response,h.shell);});
test('failed module fetch does not receive HTML as a fake JavaScript response',async()=>{const h=harness();let response;h.handlers.fetch({request:{method:'GET',mode:'cors',url:'https://example.com/session.js'},respondWith:p=>{response=p;}});assert.equal((await response).status,503);});
test('cache upgrade preserves other applications on the same origin',async()=>{const h=harness();let pending;h.handlers.activate({waitUntil:p=>{pending=p;}});await pending;assert.deepEqual(h.deleted,['roam-v1']);});
